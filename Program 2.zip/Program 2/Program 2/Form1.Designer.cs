﻿namespace Program_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MarginalTaxRateTitlelbl = new System.Windows.Forms.Label();
            this.enterTaxInclbl = new System.Windows.Forms.Label();
            this.taxableIncometxt = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.headOfHouseRadiobutton = new System.Windows.Forms.RadioButton();
            this.marriedSeparatelyRadiobutton = new System.Windows.Forms.RadioButton();
            this.marriedJointlyRadiobutton = new System.Windows.Forms.RadioButton();
            this.singleRadiobutton = new System.Windows.Forms.RadioButton();
            this.calcTaxbttn = new System.Windows.Forms.Button();
            this.marginalTaxRatelbl = new System.Windows.Forms.Label();
            this.incomeTaxlbl = new System.Windows.Forms.Label();
            this.outIncomeTaxlbl = new System.Windows.Forms.Label();
            this.outMarginalTaxRatelbl = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // MarginalTaxRateTitlelbl
            // 
            this.MarginalTaxRateTitlelbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MarginalTaxRateTitlelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.MarginalTaxRateTitlelbl.Location = new System.Drawing.Point(67, 9);
            this.MarginalTaxRateTitlelbl.Name = "MarginalTaxRateTitlelbl";
            this.MarginalTaxRateTitlelbl.Size = new System.Drawing.Size(377, 30);
            this.MarginalTaxRateTitlelbl.TabIndex = 0;
            this.MarginalTaxRateTitlelbl.Text = "2019 Marginal Tax Rate Calculations";
            // 
            // enterTaxInclbl
            // 
            this.enterTaxInclbl.AutoSize = true;
            this.enterTaxInclbl.Location = new System.Drawing.Point(12, 84);
            this.enterTaxInclbl.Name = "enterTaxInclbl";
            this.enterTaxInclbl.Size = new System.Drawing.Size(168, 20);
            this.enterTaxInclbl.TabIndex = 1;
            this.enterTaxInclbl.Text = "Enter Taxable Income:";
            // 
            // taxableIncometxt
            // 
            this.taxableIncometxt.Location = new System.Drawing.Point(207, 81);
            this.taxableIncometxt.Name = "taxableIncometxt";
            this.taxableIncometxt.Size = new System.Drawing.Size(139, 26);
            this.taxableIncometxt.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.headOfHouseRadiobutton);
            this.groupBox1.Controls.Add(this.marriedSeparatelyRadiobutton);
            this.groupBox1.Controls.Add(this.marriedJointlyRadiobutton);
            this.groupBox1.Controls.Add(this.singleRadiobutton);
            this.groupBox1.Location = new System.Drawing.Point(31, 154);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(403, 235);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Filing Status";
            // 
            // headOfHouseRadiobutton
            // 
            this.headOfHouseRadiobutton.AutoSize = true;
            this.headOfHouseRadiobutton.Location = new System.Drawing.Point(23, 188);
            this.headOfHouseRadiobutton.Name = "headOfHouseRadiobutton";
            this.headOfHouseRadiobutton.Size = new System.Drawing.Size(172, 24);
            this.headOfHouseRadiobutton.TabIndex = 3;
            this.headOfHouseRadiobutton.Text = "Head of Household";
            this.headOfHouseRadiobutton.UseVisualStyleBackColor = true;
            // 
            // marriedSeparatelyRadiobutton
            // 
            this.marriedSeparatelyRadiobutton.AutoSize = true;
            this.marriedSeparatelyRadiobutton.Location = new System.Drawing.Point(23, 139);
            this.marriedSeparatelyRadiobutton.Name = "marriedSeparatelyRadiobutton";
            this.marriedSeparatelyRadiobutton.Size = new System.Drawing.Size(208, 24);
            this.marriedSeparatelyRadiobutton.TabIndex = 2;
            this.marriedSeparatelyRadiobutton.Text = "Married Filing Separately";
            this.marriedSeparatelyRadiobutton.UseVisualStyleBackColor = true;
            // 
            // marriedJointlyRadiobutton
            // 
            this.marriedJointlyRadiobutton.AutoSize = true;
            this.marriedJointlyRadiobutton.Location = new System.Drawing.Point(23, 90);
            this.marriedJointlyRadiobutton.Name = "marriedJointlyRadiobutton";
            this.marriedJointlyRadiobutton.Size = new System.Drawing.Size(176, 24);
            this.marriedJointlyRadiobutton.TabIndex = 1;
            this.marriedJointlyRadiobutton.Text = "Married Filing Jointly";
            this.marriedJointlyRadiobutton.UseVisualStyleBackColor = true;
            // 
            // singleRadiobutton
            // 
            this.singleRadiobutton.AutoSize = true;
            this.singleRadiobutton.Checked = true;
            this.singleRadiobutton.Location = new System.Drawing.Point(23, 48);
            this.singleRadiobutton.Name = "singleRadiobutton";
            this.singleRadiobutton.Size = new System.Drawing.Size(78, 24);
            this.singleRadiobutton.TabIndex = 0;
            this.singleRadiobutton.TabStop = true;
            this.singleRadiobutton.Text = "Single";
            this.singleRadiobutton.UseVisualStyleBackColor = true;
            // 
            // calcTaxbttn
            // 
            this.calcTaxbttn.Location = new System.Drawing.Point(150, 407);
            this.calcTaxbttn.Name = "calcTaxbttn";
            this.calcTaxbttn.Size = new System.Drawing.Size(126, 37);
            this.calcTaxbttn.TabIndex = 0;
            this.calcTaxbttn.Text = "Calculate Tax";
            this.calcTaxbttn.UseVisualStyleBackColor = true;
            this.calcTaxbttn.Click += new System.EventHandler(this.calcTaxbttn_Click);
            // 
            // marginalTaxRatelbl
            // 
            this.marginalTaxRatelbl.AutoSize = true;
            this.marginalTaxRatelbl.Location = new System.Drawing.Point(27, 473);
            this.marginalTaxRatelbl.Name = "marginalTaxRatelbl";
            this.marginalTaxRatelbl.Size = new System.Drawing.Size(141, 20);
            this.marginalTaxRatelbl.TabIndex = 4;
            this.marginalTaxRatelbl.Text = "Marginal Tax Rate:";
            // 
            // incomeTaxlbl
            // 
            this.incomeTaxlbl.AutoSize = true;
            this.incomeTaxlbl.Location = new System.Drawing.Point(73, 528);
            this.incomeTaxlbl.Name = "incomeTaxlbl";
            this.incomeTaxlbl.Size = new System.Drawing.Size(95, 20);
            this.incomeTaxlbl.TabIndex = 5;
            this.incomeTaxlbl.Text = "Income Tax:";
            // 
            // outIncomeTaxlbl
            // 
            this.outIncomeTaxlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outIncomeTaxlbl.Location = new System.Drawing.Point(225, 528);
            this.outIncomeTaxlbl.Name = "outIncomeTaxlbl";
            this.outIncomeTaxlbl.Size = new System.Drawing.Size(100, 23);
            this.outIncomeTaxlbl.TabIndex = 6;
            // 
            // outMarginalTaxRatelbl
            // 
            this.outMarginalTaxRatelbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outMarginalTaxRatelbl.Location = new System.Drawing.Point(225, 473);
            this.outMarginalTaxRatelbl.Name = "outMarginalTaxRatelbl";
            this.outMarginalTaxRatelbl.Size = new System.Drawing.Size(100, 23);
            this.outMarginalTaxRatelbl.TabIndex = 7;
            // 
            // Form1
            // 
            this.AcceptButton = this.calcTaxbttn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(478, 594);
            this.Controls.Add(this.outMarginalTaxRatelbl);
            this.Controls.Add(this.outIncomeTaxlbl);
            this.Controls.Add(this.incomeTaxlbl);
            this.Controls.Add(this.marginalTaxRatelbl);
            this.Controls.Add(this.calcTaxbttn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.taxableIncometxt);
            this.Controls.Add(this.enterTaxInclbl);
            this.Controls.Add(this.MarginalTaxRateTitlelbl);
            this.Name = "Form1";
            this.Text = "Program 2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MarginalTaxRateTitlelbl;
        private System.Windows.Forms.Label enterTaxInclbl;
        private System.Windows.Forms.TextBox taxableIncometxt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button calcTaxbttn;
        private System.Windows.Forms.Label marginalTaxRatelbl;
        private System.Windows.Forms.Label incomeTaxlbl;
        private System.Windows.Forms.Label outIncomeTaxlbl;
        private System.Windows.Forms.Label outMarginalTaxRatelbl;
        private System.Windows.Forms.RadioButton headOfHouseRadiobutton;
        private System.Windows.Forms.RadioButton marriedSeparatelyRadiobutton;
        private System.Windows.Forms.RadioButton marriedJointlyRadiobutton;
        private System.Windows.Forms.RadioButton singleRadiobutton;
    }
}

