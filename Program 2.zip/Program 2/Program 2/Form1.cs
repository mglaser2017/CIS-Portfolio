﻿/*
Grading ID: N2636
Program #2
Due Date: Tuesday, March 5 (by 11:59 PM)
Course Section: CIS 199-75
This program calculates the Marginal Tax Rate and Income Tax depending on your Filing Status based on your Taxable Income.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcTaxbttn_Click(object sender, EventArgs e)
        {
            const double TaxRate1 = 0.10; //Defining Tax Rate 1
            const double TaxRate2 = 0.12; //Defining Tax Rate 2
            const double TaxRate3 = 0.22; //Defining Tax Rate 3
            const double TaxRate4 = 0.24; //Defining Tax Rate 4
            const double TaxRate5 = 0.32; //Defining Tax Rate 5
            const double TaxRate6 = 0.35; //Defining Tax Rate 6
            const double TaxRate7 = 0.37; //Defining Tax Rate 7

            const double SingleThreshold1 = 9700; //Declaring the Threshold for Single 1 
            const double SingleThreshold2 = 39475; //Declaring the Threshold for Single 2
            const double SingleThreshold3 = 84200; //Declaring the Threshold for Single 3
            const double SingleThreshold4 = 160725; //Declaring the Threshold for Single 4
            const double SingleThreshold5 = 204100; //Declaring the Threshold for Single 5
            const double SingleThreshold6 = 510300; //Declaring the Threshold for Single 6

            const double MarriedJointThreshold1 = 19400; //Declaring the Threshold for being Married Jointly 1
            const double MarriedJointThreshold2 = 78950; //Declaring the Threshold for being Married Jointly 2
            const double MarriedJointThreshold3 = 168400; //Declaring the Threshold for being Married Jointly 3
            const double MarriedJointThreshold4 = 321450; //Declaring the Threshold for being Married Jointly 4
            const double MarriedJointThreshold5 = 408200; //Declaring the Threshold for being Married Jointly 5
            const double MarriedJointThreshold6 = 612350; //Declaring the Threshold for being Married Jointly 6

            const double MarriedSeperateThreshold1 = 9700; //Declaring the Threshold for being Married Seperatly 1
            const double MarriedSeperateThreshold2 = 39475; //Declaring the Threshold for being Married Seperatly 2
            const double MarriedSeperateThreshold3 = 84200; //Declaring the Threshold for being Married Seperatly 3
            const double MarriedSeperateThreshold4 = 160725; //Declaring the Threshold for being Married Seperatly 4
            const double MarriedSeperateThreshold5 = 204100; //Declaring the Threshold for being Married Seperatly 5
            const double MarriedSeperateThreshold6 = 306175; //Declaring the Threshold for being Married Seperatly 6

            const double HeadOfHouseThreshold1 = 13850; //Declaring the Threshold for being Head of Household 1
            const double HeadOfHouseThreshold2 = 52850; //Declaring the Threshold for being Head of Household 2
            const double HeadOfHouseThreshold3 = 84200; //Declaring the Threshold for being Head of Household 3
            const double HeadOfHouseThreshold4 = 160700; //Declaring the Threshold for being Head of Household 4
            const double HeadOfHouseThreshold5 = 204100; //Declaring the Threshold for being Head of Household 5
            const double HeadOfHouseThreshold6 = 510300; //Declaring the Threshold for being Head of Household 6

            double taxIncome; //Defining Income Tax
            double taxDue; //Defining Tax Due
            double marginalRate; //Defining Marginal Rate
            const int make_Percent = 100; //Number to make Marginal Rate a percent

            //Input

            //Input for Single
            if (singleRadiobutton.Checked)
            {
                if (double.TryParse(taxableIncometxt.Text, out taxIncome) && taxIncome >= 0)
                {
                    if (taxIncome <= SingleThreshold1)
                    {
                        marginalRate = TaxRate1;
                        taxDue = taxIncome * TaxRate1;
                    }
                    else if (taxIncome <= SingleThreshold2)
                    {
                        marginalRate = TaxRate2;
                        taxDue = SingleThreshold1 * TaxRate1 + (taxIncome - SingleThreshold1) * TaxRate2;
                    }
                    else if (taxIncome <= SingleThreshold3)
                    {
                        marginalRate = TaxRate3;
                        taxDue = SingleThreshold1 * TaxRate1 + (SingleThreshold2 - SingleThreshold1) * TaxRate2 + (taxIncome - SingleThreshold2) * TaxRate3;
                    }
                    else if (taxIncome <= SingleThreshold4)
                    {
                        marginalRate = TaxRate4;
                        taxDue = SingleThreshold1 * TaxRate1 + (SingleThreshold2 - SingleThreshold1) * TaxRate2 + (SingleThreshold3 - SingleThreshold2) * TaxRate3 + (taxIncome - SingleThreshold3) * TaxRate4;
                    }
                    else if (taxIncome <= SingleThreshold5)
                    {
                        marginalRate = TaxRate5;
                        taxDue = SingleThreshold1 * TaxRate1 + (SingleThreshold2 - SingleThreshold1) * TaxRate2 + (SingleThreshold3 - SingleThreshold2) * TaxRate3 + (SingleThreshold4 - SingleThreshold3) * TaxRate4 + (taxIncome - SingleThreshold4) * TaxRate5;
                       
                    }
                    else if (taxIncome <= SingleThreshold6)
                    {
                        marginalRate = TaxRate6;
                        taxDue = SingleThreshold1 * TaxRate1 + (SingleThreshold2 - SingleThreshold1) * TaxRate2 + (SingleThreshold3 - SingleThreshold2) * TaxRate3 + (SingleThreshold4 - SingleThreshold3) * TaxRate4 + (SingleThreshold5 - SingleThreshold4) * TaxRate5 + (taxIncome - SingleThreshold5) * TaxRate6;
                    }
                    else
                    {
                        marginalRate = TaxRate7;
                        taxDue = SingleThreshold1 * TaxRate1 + (SingleThreshold2 - SingleThreshold1) * TaxRate2 + (SingleThreshold3 - SingleThreshold2) * TaxRate3 + (SingleThreshold4 - SingleThreshold3) * TaxRate4 + (SingleThreshold5 - SingleThreshold4) * TaxRate5 + (SingleThreshold6 - SingleThreshold5) * TaxRate6 + (taxIncome - SingleThreshold6) * TaxRate7;
                    }

                    //Output

                    outMarginalTaxRatelbl.Text = $"{marginalRate * make_Percent}%";
                    outIncomeTaxlbl.Text = $"{taxDue:C}";
                }
                
            }

            //Input for Married Jointly

            else if (marriedJointlyRadiobutton.Checked)
            {
                if (double.TryParse(taxableIncometxt.Text, out taxIncome) && taxIncome >= 0)
                {
                    if (taxIncome <= MarriedJointThreshold1)
                    {
                        marginalRate = TaxRate1;
                        taxDue = taxIncome * TaxRate1;
                    }
                    else if (taxIncome <= MarriedJointThreshold2)
                    {
                        marginalRate = TaxRate2;
                        taxDue = MarriedJointThreshold1 * TaxRate1 + (taxIncome - MarriedJointThreshold1) * TaxRate2;
                    }
                    else if (taxIncome <= MarriedJointThreshold3)
                    {
                        marginalRate = TaxRate3;
                        taxDue = MarriedJointThreshold1 * TaxRate1 + (MarriedJointThreshold2 - MarriedJointThreshold1) * TaxRate2 + (taxIncome - MarriedJointThreshold2) * TaxRate3;
                    }
                    else if (taxIncome <= MarriedJointThreshold4)
                    {
                        marginalRate = TaxRate4;
                        taxDue = MarriedJointThreshold1 * TaxRate1 + (MarriedJointThreshold2 - MarriedJointThreshold1) * TaxRate2 + (MarriedJointThreshold3 - MarriedJointThreshold2) * TaxRate3 + (taxIncome - MarriedJointThreshold3) * TaxRate4;
                    }
                    else if (taxIncome <= MarriedJointThreshold5)
                    {
                        marginalRate = TaxRate5;
                        taxDue = MarriedJointThreshold1 * TaxRate1 + (MarriedJointThreshold2 - MarriedJointThreshold1) * TaxRate2 + (MarriedJointThreshold3 - MarriedJointThreshold2) * TaxRate3 + (MarriedJointThreshold4 - MarriedJointThreshold3) * TaxRate4 + (taxIncome - MarriedJointThreshold4) * TaxRate5;
                    }
                    else if (taxIncome <= MarriedJointThreshold6)
                    {
                        marginalRate = TaxRate6;
                        taxDue = MarriedJointThreshold1 * TaxRate1 + (MarriedJointThreshold2 - MarriedJointThreshold1) * TaxRate2 + (MarriedJointThreshold3 - MarriedJointThreshold2) * TaxRate3 + (MarriedJointThreshold4 - MarriedJointThreshold3) * TaxRate4 + (MarriedJointThreshold5 - MarriedJointThreshold4) * TaxRate5 + (taxIncome - MarriedJointThreshold5) * TaxRate6;   
                    }
                    else
                    {
                        marginalRate = TaxRate7;
                        taxDue = MarriedJointThreshold1 * TaxRate1 + (MarriedJointThreshold2 - MarriedJointThreshold1) * TaxRate2 + (MarriedJointThreshold3 - MarriedJointThreshold2) * TaxRate3 + (MarriedJointThreshold4 - MarriedJointThreshold3) * TaxRate4 + (MarriedJointThreshold5 - MarriedJointThreshold4) * TaxRate5 + (MarriedJointThreshold6 - MarriedJointThreshold5) * TaxRate6 + (taxIncome - MarriedJointThreshold6) * TaxRate7;
                    }

                    //Output

                    outMarginalTaxRatelbl.Text = $"{marginalRate * make_Percent}%";
                    outIncomeTaxlbl.Text = $"{taxDue:C}";
                }

            }

            //Input for Married Seperately

            else if (marriedSeparatelyRadiobutton.Checked)
            {
                if (double.TryParse(taxableIncometxt.Text, out taxIncome) && taxIncome >= 0)
                {
                    if (taxIncome <= MarriedSeperateThreshold1)
                    {
                        marginalRate = TaxRate1;
                        taxDue = taxIncome * TaxRate1;
                    }
                    else if (taxIncome <= MarriedSeperateThreshold2)
                    {
                        marginalRate = TaxRate2;
                        taxDue = MarriedSeperateThreshold1 * TaxRate1 + (taxIncome - MarriedSeperateThreshold1) * TaxRate2;
                    }
                    else if (taxIncome <= MarriedSeperateThreshold3)
                    {
                        marginalRate = TaxRate3;
                        taxDue = MarriedSeperateThreshold1 * TaxRate1 + (MarriedSeperateThreshold2 - MarriedSeperateThreshold1) * TaxRate2 + (taxIncome - MarriedSeperateThreshold2) * TaxRate3;
                    }
                    else if (taxIncome <= MarriedSeperateThreshold4)
                    {
                        marginalRate = TaxRate4;
                        taxDue = MarriedSeperateThreshold1 * TaxRate1 + (MarriedSeperateThreshold2 - MarriedSeperateThreshold1) * TaxRate2 + (MarriedSeperateThreshold3 - MarriedSeperateThreshold2) * TaxRate3 + (taxIncome - MarriedSeperateThreshold3) * TaxRate4;
                    }
                    else if (taxIncome <= MarriedSeperateThreshold5)
                    {
                        marginalRate = TaxRate5;
                        taxDue = MarriedSeperateThreshold1 * TaxRate1 + (MarriedSeperateThreshold2 - MarriedSeperateThreshold1) * TaxRate2 + (MarriedSeperateThreshold3 - MarriedSeperateThreshold2) * TaxRate3 + (MarriedSeperateThreshold4 - MarriedSeperateThreshold3) * TaxRate4 + (taxIncome - MarriedSeperateThreshold4) * TaxRate5;  
                    }
                    else if (taxIncome <= MarriedSeperateThreshold6)
                    {
                        marginalRate = TaxRate6;
                        taxDue = MarriedSeperateThreshold1 * TaxRate1 + (MarriedSeperateThreshold2 - MarriedSeperateThreshold1) * TaxRate2 + (MarriedSeperateThreshold3 - MarriedSeperateThreshold2) * TaxRate3 + (MarriedSeperateThreshold4 - MarriedSeperateThreshold3) * TaxRate4 + (MarriedSeperateThreshold5 - MarriedSeperateThreshold4) * TaxRate5 + (taxIncome - MarriedSeperateThreshold5) * TaxRate6; 
                    }
                    else
                    {
                        marginalRate = TaxRate7;
                        taxDue = MarriedSeperateThreshold1 * TaxRate1 + (MarriedSeperateThreshold2 - MarriedSeperateThreshold1) * TaxRate2 + (MarriedSeperateThreshold3 - MarriedSeperateThreshold2) * TaxRate3 + (MarriedSeperateThreshold4 - MarriedSeperateThreshold3) * TaxRate4 + (MarriedSeperateThreshold5 - MarriedSeperateThreshold4) * TaxRate5 + (MarriedSeperateThreshold6 - MarriedSeperateThreshold5) * TaxRate6 + (taxIncome - MarriedSeperateThreshold6) * TaxRate7;
                    }

                    //Output

                    outMarginalTaxRatelbl.Text = $"{marginalRate * make_Percent}%";
                    outIncomeTaxlbl.Text = $"{taxDue:C}";
                }
            }

            //Input for Head of Household

            else if (headOfHouseRadiobutton.Checked)
                {
                if (double.TryParse(taxableIncometxt.Text, out taxIncome) && taxIncome >= 0)
                {
                    if (taxIncome <= HeadOfHouseThreshold1)
                    {
                        marginalRate = TaxRate1;
                        taxDue = taxIncome * TaxRate1;
                    }
                    else if (taxIncome <= HeadOfHouseThreshold2)
                    {
                        marginalRate = TaxRate2;
                        taxDue = HeadOfHouseThreshold1 * TaxRate1 + (taxIncome - HeadOfHouseThreshold1) * TaxRate2;
                    }
                    else if (taxIncome <= HeadOfHouseThreshold3)
                    {
                        marginalRate = TaxRate3;
                        taxDue = HeadOfHouseThreshold1 * TaxRate1 + (HeadOfHouseThreshold2 - HeadOfHouseThreshold1) * TaxRate2 + (taxIncome - HeadOfHouseThreshold2) * TaxRate3;
                    }
                    else if (taxIncome <= HeadOfHouseThreshold4)
                    {
                        marginalRate = TaxRate4;
                        taxDue = HeadOfHouseThreshold1 * TaxRate1 + (HeadOfHouseThreshold2 - HeadOfHouseThreshold1) * TaxRate2 + (HeadOfHouseThreshold3 - HeadOfHouseThreshold2) * TaxRate3 + (taxIncome - HeadOfHouseThreshold3) * TaxRate4;
                    }
                    else if (taxIncome <= HeadOfHouseThreshold5)
                    {
                        marginalRate = TaxRate5;
                        taxDue = HeadOfHouseThreshold1 * TaxRate1 + (HeadOfHouseThreshold2 - HeadOfHouseThreshold1) * TaxRate2 + (HeadOfHouseThreshold3 - HeadOfHouseThreshold2) * TaxRate3 + (HeadOfHouseThreshold4 - HeadOfHouseThreshold3) * TaxRate4 + (taxIncome - HeadOfHouseThreshold4) * TaxRate5;  
                    }
                    else if (taxIncome <= HeadOfHouseThreshold6)
                    {
                        marginalRate = TaxRate6;
                        taxDue = HeadOfHouseThreshold1 * TaxRate1 + (HeadOfHouseThreshold2 - HeadOfHouseThreshold1) * TaxRate2 + (HeadOfHouseThreshold3 - HeadOfHouseThreshold2) * TaxRate3 + (HeadOfHouseThreshold4 - HeadOfHouseThreshold3) * TaxRate4 + (HeadOfHouseThreshold5 - HeadOfHouseThreshold4) * TaxRate5 + (taxIncome - HeadOfHouseThreshold5) * TaxRate6; 
                    }
                    else
                    {
                        marginalRate = TaxRate7;
                        taxDue = HeadOfHouseThreshold1 * TaxRate1 + (HeadOfHouseThreshold2 - HeadOfHouseThreshold1) * TaxRate2 + (HeadOfHouseThreshold3 - HeadOfHouseThreshold2) * TaxRate3 + (HeadOfHouseThreshold4 - HeadOfHouseThreshold3) * TaxRate4 + (HeadOfHouseThreshold5 - HeadOfHouseThreshold4) * TaxRate5 + (HeadOfHouseThreshold6 - HeadOfHouseThreshold5) * TaxRate6 + (taxIncome - HeadOfHouseThreshold6) * TaxRate7;
                        
                    }

                    //Output

                    outMarginalTaxRatelbl.Text = $"{marginalRate * make_Percent}%";
                    outIncomeTaxlbl.Text = $"{taxDue:C}";
                }
            }
            
        }
    }
}
