﻿/*
 * Grading ID: N2636
 * Assignment: Program 4
 * Due Date: 4/23/19 11:59:00 PM
 * Section: CIS 199-75
 * This program uses the inputed origin zip code, destination zip code, length, width, height, and weight to determine the shipping cost
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    class GroundPackage
    {
        
        private int originZip;     //Variable that stores the origin zip code of the package
        private int destinatonZip; //Variable that stores the of the destination zip code package
        private double length;     //Variable that stores the length of the package
        private double width;      //Variable that stores the width of the package
        private double height;     //Variable that stores the height of the package
        private double weight;     //Variable that stores the weight of the package

        //Constants
        int lowOriginZip = 10000;          //Constant for the low origin zip code
        int highOriginZip = 99999;         //Constant for the high origin zip code
        int defaultOriginZip = 40202;      //Constant for the default origin zip code if the code inputed is invalid
        int defaultDestinationZip = 90210; //Constant for the default destination zip code if the code inputed is invalid
        double defaultvalue = 1.0;         //Constant for the default value for the length, width, height, and weight  
        double lowLength = 0;
        double lowWidth = 0;
        double lowHeight = 0;
        double lowWeight = 0;
        const double SIZE_COST_FACTOR = .25;
        const double WEIGHT_COST_FACTOR = .45;

        // Constructor to initialize data members
        // Use properties to set values
        public GroundPackage(int o, int d, double l, double w, double h, double we)
        {
            OriginZip = o;
            DestinatonZip = d;
            Length = l;
            Height = h;
            Width = w;
            Weight = we;

        }

        //Properties for all data members
        public int OriginZip
        {
            //Precondition: None
            //Postcondition: Returns the Origin Zip Code
            get { return originZip; }
            //Precondition: Value must be greater than or equal to the low origin zip code AND less than or equal to the high origin zip code
            //Postcondition: This sets the origin zip code to the default origin zip code
            set
            {
                //This is saying if the value that is inputed is not valid input, default the value to 40202
                if (value >= lowOriginZip && value <= highOriginZip)
                    originZip = value;
                else
                    originZip = defaultOriginZip;
            }
        }

        public int DestinatonZip
        {
            //Precondition: None
            //Postcondition: Returns the Distination Zip Code
            get { return destinatonZip; }
            //Precondition: Value must be greater than or equal to the low destination zip code AND less than or equal to the high destination zip code
            //Postcondition: This sets the destination zip code to the default destination zip code
            set
            {
                //This is saying if the value that is inputed is not valid input, default the value to 90210
                if (value >= lowOriginZip && value <= highOriginZip)
                    destinatonZip = value;
                else
                    destinatonZip = defaultDestinationZip;
            }
        }

        public double Length
        {
            //Precondition: None
            //Postcondition: Returns the Length of the package
            get { return length; }
            //Precondition: Value must be greater than the low length threshold(0)
            //Postcondition: This sets the length of the package to the default value(1.0)
            set
            {
                //This is saying if the value that is inputed is not valid input, default the value to 1
                if (value > lowLength)
                    length = value;
                else
                    length = defaultvalue;
            }
        }

        public double Width
        {
            //Precondition: None
            //Postcondition: Returns the Width of the package
            get { return width; }
            //Precondition: Value must be greater than the low width threshold(0)
            //Postcondition: This sets the width of the package to the default value(1.0)
            set
            {
                //This is saying if the value that is inputed is not valid input, default the value to 1
                if (value > lowWidth)
                    width = value;
                else
                    width = defaultvalue;
            }
        }

        public double Height
        {
            //Precondition: None
            //Postcondition: Returns the Height of the package
            get { return height; }
            //Precondition: Value must be greater than the low height threshold(0)
            //Postcondition: This sets the height of the package to the default value(1.0)
            set
            {
                //This is saying if the value that is inputed is not valid input, default the value to 1
                if (value > lowHeight)
                    height = value;
                else
                    height = defaultvalue;
            }
        }

        public double Weight
        {
            //Precondition: None
            //Postcondition: Returns the Weight of the package
            get { return weight; }
            //Precondition: Value must be greater than the low weight threshold(0)
            //Postcondition: This sets the weight of the package to the default value(1.0)
            set
            {
                //This is saying if the value that is inputed is not valid input, default the value to 1
                if (value > lowWeight)
                    weight = value;
                else
                    weight = defaultvalue;
            }
        }

        public int ZoneDistance
        {
            //Precondition: Find the first digit of origin zip and the first digit of destination zip.
            //Postcondition: Returns absolute value of the first Origin digit minus the first Destination zip.
            get
            {
                int firstO = OriginZip / 10000;
                int firstD = DestinatonZip / 10000;
                return Math.Abs(firstO - firstD);
            }
        }

        public override string ToString()
        {

            //Here I used string interpolation to format the strings
            //In {"Origin ZipCode",-22} the -22 is goign to set the string to left with a width of 22 spaces
            //The above comment goes for all of the other strings
            return $"{"Origin ZipCode",-22}: {OriginZip}" + Environment.NewLine + $"{"Destination ZipCode",-22}: {DestinatonZip}" + Environment.NewLine + $"{"Length",-22}: {Length}" + Environment.NewLine + $"{"Height",-22}: {Height}" + Environment.NewLine + $"{"Width",-22}: {Width}" + Environment.NewLine + $"{"Weight",-22}: {Weight}";
        }

        public double CalcCost()
        {
            //This formula calculates the cost and then returns it
            double cost = SIZE_COST_FACTOR * (Length + Width + Height) + WEIGHT_COST_FACTOR * (ZoneDistance + 1) * (Weight);
            return cost;
        }
    }
}
