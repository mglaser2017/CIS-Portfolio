﻿/*
 * Grading ID: N2636
 * Assignment: Program 4
 * Due Date: 4/23/19 11:59:00 PM
 * Section: CIS 199-75
 * This program uses the inputed origin zip code, destination zip code, length, width, height, and weight to determine the shipping cost
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    class GroundPackageTestClass
    {
        static void Main(string[] args)
        {
            {

                //This create 5 objects of GroundPackage class
                GroundPackage gp1 = new GroundPackage(41075, 41072, 40, 30, 50, 10);
                GroundPackage gp2 = new GroundPackage(86753, 09867 , 53, 09, 86, 75);
                GroundPackage gp3 = new GroundPackage(85962, 07530, 26, 57, 91, 155);
                GroundPackage gp4 = new GroundPackage(98770, 12934, 31, 59, 34, 123);
                GroundPackage gp5 = new GroundPackage(34455, 11223, 142, 96, 69, 167);

                //This creates an array and stores these objects in the packages array
                GroundPackage[] packages = { gp1, gp2, gp3, gp4, gp5 };

                //This calls the function to display packages
                DisplayPackages(packages);

                Console.WriteLine("\n----------------------------");
                Console.WriteLine("\n----------------------------");

                Console.WriteLine("Changed Packages");
                Console.WriteLine("\n----------------------------");
                //Change gp1 and display it
                gp1.OriginZip = 40202;
                gp1.Height = 97;
                display(gp1);

                //Change gp2 and display it
                gp2.Length = -1;
                display(gp2);

                //Change gp3 and display it
                gp3.Weight = 222;
                gp3.Width = 46;
                display(gp3);

                //Change gp4 and display it
                gp4.Weight = 222;
                gp4.Height = 86;
                display(gp4);

                //Change gp5 and display it
                gp5.Weight = 54;
                gp5.DestinatonZip = 46123;
                gp5.Length = 154;
                display(gp5);
            }

            void DisplayPackages(GroundPackage[] packages)
            {
                //Iterate loop over packages array
                //This prints the package number, the object at index i, and shipping cost by calling the function CalcCost
                for (int i = 0; i < packages.Length; i++)
                {
                    Console.WriteLine("Package " + (i + 1) + "\n-----------------------------");
                    Console.WriteLine(packages[i]);
                    Console.WriteLine($"{"Shipping Cost",-22}: ${ packages[i].CalcCost()}");
                    Console.WriteLine();
                }
            }

            void display(GroundPackage package)
            {
                //This prints the package and the shipping cost by calling the function
                Console.WriteLine(package);
                Console.WriteLine($"{"Shipping Cost",-22}: ${ package.CalcCost()}");
                Console.WriteLine();

            }
        }
    }
}
     
