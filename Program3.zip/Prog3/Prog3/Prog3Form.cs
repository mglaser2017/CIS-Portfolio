﻿// Program 3
// CIS 199-75
// Due: 3/30/2019
// Grading ID: N2636

// This application calculates the marginal tax rate and
// tax due for filers in 2019 tax year.

// Version 3
// Listens to radio buttons to apply income thresholds
// Calculates tax due through running total with each
// tier's portion of the tax.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog3
{
    public partial class Prog3Form : Form
    {
        // Tax Year 2019 Data
        // Taxable income thresholds for each status
        // Single Filers
        private const int SINGLE0 = 1;      // Base single threshold
        private const int SINGLE1 = 9701;   // 1st single threshold (LOWEST)
        private const int SINGLE2 = 39476;  // 2nd single threshold
        private const int SINGLE3 = 84201;  // 3rd single threshold
        private const int SINGLE4 = 160726; // 4th single threshold
        private const int SINGLE5 = 204101; // 5th single threshold
        private const int SINGLE6 = 510301; // 6th single threshold (HIGHEST)

        //Married Filing Separately
        private const int SEPARATELY0 = 1;      // Base married-separately threshold
        private const int SEPARATELY1 = 9701;   // 1st married-separately threshold (LOWEST)
        private const int SEPARATELY2 = 39476;  // 2nd married-separately threshold
        private const int SEPARATELY3 = 84201;  // 3rd married-separately threshold
        private const int SEPARATELY4 = 160726; // 4th married-separately threshold
        private const int SEPARATELY5 = 204101; // 5th married-separately threshold
        private const int SEPARATELY6 = 306176; // 6th married-separately threshold (HIGHEST)

        // Married Filing Jointly
        private const int JOINTLY0 = 1;      // Base married jointly threshold
        private const int JOINTLY1 = 19401;  // 1st married-jointly threshold (LOWEST)
        private const int JOINTLY2 = 78951;  // 2nd married-jointly threshold
        private const int JOINTLY3 = 168401; // 3rd married-jointly threshold
        private const int JOINTLY4 = 321451; // 4th married-jointly threshold
        private const int JOINTLY5 = 408201; // 5th married-jointly threshold
        private const int JOINTLY6 = 612351; // 6th married-jointly threshold (HIGHEST)

        // Head of Household
        private const int HOH0 = 1;      // Base head of household threshold
        private const int HOH1 = 13851;  // 1st head of household threshold (LOWEST)
        private const int HOH2 = 52851;  // 2nd head of household threshold
        private const int HOH3 = 84201;  // 3rd head of household threshold
        private const int HOH4 = 160701; // 4th head of household threshold
        private const int HOH5 = 204101; // 5th head of household threshold
        private const int HOH6 = 510301; // 6th head of household threshold (HIGHEST)

        // Income threshold values that apply to this filer
        //private int threshold1; // 1st income threshold
        //private int threshold2; // 2nd income threshold
        //private int threshold3; // 3rd income threshold
        //private int threshold4; // 4th income threshold
        //private int threshold5; // 5th income threshold
        //private int threshold6; // 6th income threshold

        const int Num_Rates = 7;
        int[] thresholds = new int[Num_Rates];

        public Prog3Form()
        {
            InitializeComponent();
        }

        // User has clicked the Calculate Tax button
        // Will calculate and display their marginal tax rate and tax due
        private void calcTaxBtn_Click(object sender, EventArgs e)
        {
            // Tax Year 2019 Data
            // The marginal tax rates
            const decimal RATE1 = .10m; // 1st tax rate (LOWEST)
            const decimal RATE2 = .12m; // 2nd tax rate
            const decimal RATE3 = .22m; // 3rd tax rate
            const decimal RATE4 = .24m; // 4th tax rate
            const decimal RATE5 = .32m; // 5th tax rate
            const decimal RATE6 = .35m; // 6th tax rate
            const decimal RATE7 = .37m; // 7th tax rate (HIGHEST)

            decimal[] rates = { RATE1, RATE2, RATE3, RATE4, RATE5, RATE6, RATE7 }; //Array for the decimal rates

            int income; // Filer's taxable income (input)

            decimal marginalRate = 0; // Filer's calculated marginal tax rate
            decimal tax = 0;          // Filer's calculated income tax due
            decimal currentTax;   // Filer's tax for current tier
            bool found = false;
            int i;  

            if (int.TryParse(incomeTxt.Text, out income) && income >= 0)
            {

                // Calculate income tax due and find their marginal rate

                // Math.Min returns the smaller of two values

                int index = thresholds.Length - 1;

                while (index >= 0 && !found)
                {

                    if (income >= thresholds[index])
                        found = true;

                    else
                        --index;
                }

                if (found)
                {
                    marginalRate = rates[index];
                   
                }

                for (i = 0; i <= index; ++i)
                {
                    currentTax = Math.Min(income - (thresholds[i] - 1), (thresholds[i + 1] - thresholds[i])) * rates[i];
                    tax += currentTax;
                }
                if (index > thresholds.Length - 1)
                {
                    marginalRate = thresholds[i];
                    currentTax = (income - thresholds[5]) * rates[i];
                    tax += currentTax;
                  
                }

              

                // Output results
                marginalRateOutLbl.Text = $"{marginalRate:P0}"; //Output for Marginal Tax Rate
                taxOutLbl.Text = $"{tax:C}"; //Output for Income Tax
            }
            else // Invalid input
                MessageBox.Show("Enter valid income!");
        }

        // Form is loading
        // Sets default filing status as Single
        private void Prog2Form_Load(object sender, EventArgs e)
        {
            singleRdoBtn.Checked = true; // Choose single by default
                                         // Will raise CheckedChanged event
        }

        // User has checked/unchecked Single radio button
        // Updates income thresholds
        private void singleRdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (singleRdoBtn.Checked) // Single
            {
                thresholds[0] = SINGLE0;
                thresholds[1] = SINGLE1;
                thresholds[2] = SINGLE2;
                thresholds[3] = SINGLE3;
                thresholds[4] = SINGLE4;
                thresholds[5] = SINGLE5;
                thresholds[6] = SINGLE6;
            }
        }

        // User has checked/unchecked Married Filing Separately radio button
        // Updates income thresholds
        private void separatelyRdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (separatelyRdoBtn.Checked) // Married Filing Separately
            {
                thresholds[0] = SEPARATELY0;
                thresholds[1] = SEPARATELY1;
                thresholds[2] = SEPARATELY2;
                thresholds[3] = SEPARATELY3;
                thresholds[4] = SEPARATELY4;
                thresholds[5] = SEPARATELY5;
                thresholds[6] = SEPARATELY6;
            }
        }

        // User has checked/unchecked Married Filing Jointly radio button
        // Updates income thresholds
        private void jointlyRdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (jointlyRdoBtn.Checked) // Married Filing Jointly
            {
                thresholds[0] = JOINTLY0;
                thresholds[1] = JOINTLY1;
                thresholds[2] = JOINTLY2;
                thresholds[3] = JOINTLY3;
                thresholds[4] = JOINTLY4;
                thresholds[5] = JOINTLY5;
                thresholds[6] = JOINTLY6;
            }
        }

        // User has checked/unchecked Head of Household radio button
        // Updates income thresholds
        private void headOfHouseRdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (headOfHouseRdoBtn.Checked) // Head of Household
            {
                thresholds[0] = HOH0;
                thresholds[1] = HOH1;
                thresholds[2] = HOH2;
                thresholds[3] = HOH3;
                thresholds[4] = HOH4;
                thresholds[5] = HOH5;
                thresholds[6] = HOH6;
            }
        }
    }
}
