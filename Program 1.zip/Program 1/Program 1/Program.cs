﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_1
{
    class Program
    {
        static void Main(string[] args)
        {

            const double Sq_Yards = 9; 
            const double Padding_Cost = 2.75;
            const double Labor_Cost = 4.50;
            const double Labor_First_Room = 100;
            double maxLength; //Variable for Length of Room
            double maxWidth; //Variable for Width of Room
            double price; //Variable for Carpet Price
            double sqYards; //Calculation of Sq Yards
            double carpetCost; //Calculation of Carpet Cost
            double laborCost; //Calculation of Labor Cost
            double paddingCost; //Calculation of Padding Cost
            double totalCost; //Calculation of Total Cost
            int numberLayers; //Variable for Number of Padding Layers
            int firstRoom; //Variable for the First Room being Yes or No

            Console.WriteLine("Welcome to Handy-Dandy Carpet Estimator"); //Title of Program
            Console.WriteLine(); //Space

            //Input for Program

            Console.Write("Enter the max width of the room (in feet): ");
            maxWidth = double.Parse(Console.ReadLine());
            Console.Write("Enter the max length of the room (in feet): ");
            maxLength = double.Parse(Console.ReadLine());
            Console.Write("Enter the carpet price (per square yeard): ");
            price = double.Parse(Console.ReadLine());
            Console.Write("Enter the layers of pading to use (1 or 2): ");
            numberLayers = int.Parse(Console.ReadLine());
            Console.Write("Is this the first room? (1 = YES, 0 = NO): ");
            firstRoom = int.Parse(Console.ReadLine());
            Console.WriteLine(); //Space

            //Calculations for Program

            sqYards = (maxLength * maxWidth) / Sq_Yards;
            paddingCost = ((Padding_Cost * sqYards) + (sqYards * 0.10 * Padding_Cost) * numberLayers);
            laborCost = (Labor_Cost * sqYards) + (firstRoom * Labor_First_Room);
            carpetCost = (sqYards * price) + (sqYards * .10 * price);
            totalCost = paddingCost + laborCost + carpetCost;


            //Output for Program

            Console.WriteLine($"Sq. Yards Needed:  {sqYards,4:F1}");
            Console.WriteLine($"Carpet Cost:  {carpetCost,10:C}");
            Console.WriteLine($"Padding Cost:  {paddingCost,9:C}");
            Console.WriteLine($"Labor Cost:  {laborCost,11:C}");
            Console.WriteLine($"Total Cost:  {totalCost,11:C}");
        }
    }
}
